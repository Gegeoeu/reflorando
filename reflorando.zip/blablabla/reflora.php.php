<?php
$impactos = [
	[
		'numero' => '01',
		'titulo' => 'Solo e água contaminados',
		'texto' => 'Baterias, placas e telas podem liberar metais e substâncias tóxicas. No lixo comum, esses materiais podem chegar ao solo e aos cursos d’água.',
		'icone' => '◉',
	],
	[
		'numero' => '02',
		'titulo' => 'Riscos para a saúde',
		'texto' => 'A exposição a contaminantes pode afetar quem vive perto de áreas de descarte irregular e quem manuseia esses resíduos sem proteção.',
		'icone' => '✳',
	],
	[
		'numero' => '03',
		'titulo' => 'Recursos desperdiçados',
		'texto' => 'Celulares e computadores guardam cobre, alumínio e outros materiais que podem voltar para a indústria quando separados corretamente.',
		'icone' => '↻',
	],
];

$destinos = [
	['passo' => '01', 'titulo' => 'Apague seus dados', 'texto' => 'Faça backup do que importa, saia das suas contas e restaure o aparelho para as configurações de fábrica. Retire chips e cartões de memória.'],
	['passo' => '02', 'titulo' => 'Separe por tipo', 'texto' => 'Mantenha pilhas e baterias separadas. Proteja terminais com fita e, se possível, guarde cada item em uma embalagem seca.'],
	['passo' => '03', 'titulo' => 'Encontre um ponto', 'texto' => 'Procure um ecoponto ou ponto de coleta de eletroeletrônicos. Redes de varejo e fabricantes também podem receber produtos antigos.'],
	['passo' => '04', 'titulo' => 'Entregue com segurança', 'texto' => 'Não desmonte, fure ou queime aparelhos. Leve-os inteiros ao coletor e confirme se o local aceita aquele tipo de material.'],
];

function e(string $texto): string
{
	return htmlspecialchars($texto, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Descubra como descartar, reciclar e reutilizar resíduos eletrônicos com mais cuidado e segurança.">
	<meta name="theme-color" content="#f9f4f4">
	<title>Reflora | Tecnologia que floresce de novo</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
	<style>
		:root {
			--ink: #263b32;
			--muted: #64746a;
			--paper: #fbf8f6;
			--pink: #f2cbd5;
			--rose: #a95268;
			--green: #dcebd8;
			--leaf: #557a5f;
			--line: #e6e9df;
			--mono: 'DM Mono', monospace;
			--body: 'DM Sans', sans-serif;
			--display: 'Manrope', sans-serif;
		}

		* { box-sizing: border-box; }
		html { scroll-behavior: smooth; scroll-padding-top: 86px; }
		body { margin: 0; color: var(--ink); background: var(--paper); font-family: var(--body); }
		a { color: inherit; }
		button { font: inherit; }
		.shell { width: min(1120px, calc(100% - 48px)); margin: 0 auto; }
		.topbar { position: sticky; z-index: 10; top: 0; border-bottom: 1px solid rgba(38,59,50,.09); background: rgba(251,248,246,.92); backdrop-filter: blur(14px); }
		.nav { min-height: 72px; display: flex; align-items: center; justify-content: space-between; gap: 28px; }
		.brand { display: inline-flex; align-items: center; gap: 10px; text-decoration: none; font-family: var(--display); font-size: 19px; font-weight: 800; letter-spacing: 0; }
		.brand-mark { width: 34px; height: 34px; display: grid; place-items: center; border: 1px solid #c9ddc8; border-radius: 50%; background: var(--green); color: var(--leaf); font-size: 18px; }
		.nav-links { display: flex; align-items: center; gap: 28px; }
		.nav-links a { color: var(--muted); font-size: 13px; font-weight: 600; text-decoration: none; }
		.nav-links a:hover { color: var(--rose); }
		.nav-cta { padding: 10px 15px; border: 1px solid #d6e4d1; border-radius: 4px; background: #edf4e9; color: var(--ink) !important; }
		.hero { position: relative; min-height: 570px; display: grid; align-items: center; overflow: hidden; background: #f5e5e6; }
		.hero::before { position: absolute; inset: 0; content: ''; background: linear-gradient(90deg, rgba(251,244,242,.96) 0%, rgba(251,244,242,.89) 46%, rgba(251,244,242,.2) 100%), url('https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=2000&q=85') center 48% / cover; }
		.hero::after { position: absolute; right: 6%; bottom: -68px; width: 210px; height: 210px; border: 1px solid rgba(85,122,95,.2); border-radius: 50%; content: '✿'; display: grid; place-items: start center; padding-top: 15px; color: rgba(85,122,95,.42); font-size: 42px; }
		.hero-inner { position: relative; z-index: 1; padding: 84px 0 96px; }
		.eyebrow { display: inline-flex; align-items: center; gap: 10px; color: var(--leaf); font: 11px var(--mono); letter-spacing: 0; text-transform: uppercase; }
		.eyebrow::before { width: 24px; height: 1px; background: var(--leaf); content: ''; }
		h1, h2, h3, p { margin-top: 0; }
		h1 { max-width: 650px; margin: 22px 0 18px; font-family: var(--display); font-size: clamp(42px, 6vw, 72px); line-height: 1.04; letter-spacing: 0; }
		h1 em { color: var(--rose); font-style: normal; }
		.hero-copy { max-width: 475px; margin-bottom: 28px; color: #53665b; font-size: 17px; line-height: 1.7; }
		.button-row { display: flex; flex-wrap: wrap; gap: 12px; }
		.button { min-height: 46px; display: inline-flex; align-items: center; justify-content: center; gap: 10px; padding: 0 18px; border: 1px solid var(--ink); border-radius: 4px; background: var(--ink); color: white; font-size: 13px; font-weight: 700; text-decoration: none; transition: transform .2s ease, background .2s ease; }
		.button:hover { transform: translateY(-2px); background: #385344; }
		.button.secondary { border-color: rgba(38,59,50,.25); background: rgba(255,255,255,.55); color: var(--ink); }
		.hero-note { display: flex; align-items: center; gap: 9px; margin-top: 28px; color: var(--muted); font: 11px var(--mono); }
		.hero-note span { color: var(--rose); font-size: 16px; }
		.ticker { border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); background: #fffdfb; }
		.ticker-inner { min-height: 66px; display: flex; align-items: center; justify-content: space-between; gap: 20px; color: var(--muted); font: 11px var(--mono); text-transform: uppercase; }
		.ticker strong { color: var(--ink); font-weight: 500; }
		.ticker .dot { color: #b9788b; padding: 0 8px; }
		section.content-section { padding: 100px 0; }
		.section-head { display: flex; align-items: end; justify-content: space-between; gap: 30px; margin-bottom: 38px; }
		.section-head h2 { max-width: 590px; margin: 12px 0 0; font-family: var(--display); font-size: clamp(30px, 4vw, 46px); line-height: 1.12; letter-spacing: 0; }
		.section-intro { max-width: 350px; margin: 0; color: var(--muted); font-size: 14px; line-height: 1.75; }
		.impact-grid { display: grid; grid-template-columns: repeat(3, 1fr); border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); }
		.impact-card { min-height: 245px; padding: 25px 26px 28px 0; }
		.impact-card + .impact-card { padding-left: 26px; border-left: 1px solid var(--line); }
		.impact-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 35px; color: var(--rose); font: 11px var(--mono); }
		.impact-icon { width: 36px; height: 36px; display: grid; place-items: center; border-radius: 50%; background: #f7e5e8; font-size: 19px; }
		.impact-card h3 { margin-bottom: 11px; font-family: var(--display); font-size: 19px; letter-spacing: 0; }
		.impact-card p { max-width: 300px; margin: 0; color: var(--muted); font-size: 13px; line-height: 1.75; }
		.callout { display: grid; grid-template-columns: 1fr auto; align-items: center; gap: 24px; margin-top: 26px; padding: 22px 25px; border: 1px solid #d7e5d2; background: #eff5eb; }
		.callout p { margin: 0; color: #49624e; font-size: 13px; line-height: 1.65; }
		.callout strong { color: var(--ink); }
		.callout-mark { color: var(--leaf); font-size: 24px; }
		.how-section { background: #f0f5ed; }
		.how-section .eyebrow { color: var(--leaf); }
		.steps { display: grid; grid-template-columns: repeat(4, 1fr); border-top: 1px solid #d7e3d2; }
		.step { padding: 23px 20px 10px 0; }
		.step + .step { padding-left: 20px; border-left: 1px solid #d7e3d2; }
		.step-number { display: inline-block; margin-bottom: 28px; color: var(--leaf); font: 11px var(--mono); }
		.step h3 { margin-bottom: 10px; font-family: var(--display); font-size: 17px; letter-spacing: 0; }
		.step p { margin: 0; color: var(--muted); font-size: 13px; line-height: 1.75; }
		.finder { display: grid; grid-template-columns: 1fr 1fr; gap: 54px; align-items: center; padding: 34px 0; border-bottom: 1px solid var(--line); }
		.finder h2 { max-width: 480px; margin: 13px 0; font-family: var(--display); font-size: clamp(28px, 3.6vw, 40px); line-height: 1.12; letter-spacing: 0; }
		.finder-copy { max-width: 470px; color: var(--muted); font-size: 14px; line-height: 1.75; }
		.finder-actions { display: flex; flex-wrap: wrap; gap: 10px; }
		.finder-link { min-height: 44px; display: inline-flex; align-items: center; gap: 10px; padding: 0 14px; border: 1px solid var(--line); border-radius: 4px; background: #fffdfb; font-size: 12px; font-weight: 700; text-decoration: none; }
		.finder-link:hover { border-color: #b9d1b3; background: #f2f7ef; }
		.reuse-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 42px; align-items: center; }
		.reuse-panel { min-height: 300px; position: relative; display: flex; align-items: end; overflow: hidden; padding: 27px; background: linear-gradient(180deg, rgba(38,59,50,.02), rgba(38,59,50,.68)), url('https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1000&q=85') center / cover; color: white; }
		.reuse-panel p { max-width: 340px; margin: 0; font-family: var(--display); font-size: 21px; font-weight: 700; line-height: 1.4; }
		.reuse-list { list-style: none; padding: 0; margin: 0; }
		.reuse-list li { display: grid; grid-template-columns: 24px 1fr; gap: 13px; padding: 15px 0; border-bottom: 1px solid var(--line); color: var(--muted); font-size: 13px; line-height: 1.65; }
		.reuse-list li:first-child { border-top: 1px solid var(--line); }
		.reuse-list span { color: var(--leaf); font-family: var(--mono); }
		.safety { display: flex; align-items: flex-start; gap: 13px; margin-top: 22px; padding: 17px; background: #f8e9eb; color: #704956; font-size: 12px; line-height: 1.7; }
		.safety strong { color: #513541; }
		.safety-mark { flex: 0 0 auto; font-size: 18px; }
		.closing { padding: 69px 0; background: #f0dce1; }
		.closing-inner { display: flex; align-items: center; justify-content: space-between; gap: 30px; }
		.closing h2 { max-width: 600px; margin: 12px 0 0; font-family: var(--display); font-size: clamp(29px, 4vw, 43px); line-height: 1.12; letter-spacing: 0; }
		footer { padding: 22px 0; background: var(--ink); color: #e0e9df; }
		.footer-inner { display: flex; align-items: center; justify-content: space-between; gap: 20px; font-size: 11px; }
		.footer-inner a { color: #e0e9df; text-decoration: none; }
		.footer-note { color: #bac9bb; }
		.reveal { animation: rise .7s both; }
		@keyframes rise { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
		@media (prefers-reduced-motion: reduce) { *, *::before, *::after { scroll-behavior: auto !important; animation-duration: .01ms !important; transition-duration: .01ms !important; } }
		@media (max-width: 760px) {
			.shell { width: min(100% - 36px, 560px); }
			.nav { min-height: 64px; }
			.nav-links { gap: 15px; }
			.nav-links a:not(.nav-cta) { display: none; }
			.hero { min-height: 570px; }
			.hero::before { background: linear-gradient(90deg, rgba(251,244,242,.97), rgba(251,244,242,.76)), url('https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=1000&q=85') center / cover; }
			.hero-inner { padding: 76px 0 90px; }
			.ticker-inner { min-height: 60px; justify-content: center; text-align: center; }
			.ticker-inner span:nth-of-type(n+2) { display: none; }
			section.content-section { padding: 72px 0; }
			.section-head { align-items: flex-start; flex-direction: column; gap: 15px; margin-bottom: 28px; }
			.impact-grid { grid-template-columns: 1fr; }
			.impact-card { min-height: auto; padding: 22px 0; }
			.impact-card + .impact-card { padding-left: 0; border-top: 1px solid var(--line); border-left: 0; }
			.impact-top { margin-bottom: 19px; }
			.callout { grid-template-columns: 1fr; }
			.callout-mark { display: none; }
			.steps { grid-template-columns: 1fr 1fr; }
			.step { padding: 18px 14px 20px 0; }
			.step + .step { padding-left: 14px; }
			.step:nth-child(3) { padding-left: 0; border-left: 0; }
			.step:nth-child(n+3) { border-top: 1px solid #d7e3d2; }
			.finder, .reuse-grid { grid-template-columns: 1fr; gap: 25px; }
			.reuse-panel { min-height: 250px; }
			.closing-inner { align-items: flex-start; flex-direction: column; }
			.footer-inner { align-items: flex-start; flex-direction: column; gap: 9px; }
		}
		@media (max-width: 380px) {
			.shell { width: calc(100% - 28px); }
			h1 { font-size: 39px; }
			.button-row { align-items: stretch; flex-direction: column; }
			.button { width: 100%; }
			.steps { grid-template-columns: 1fr; }
			.step, .step + .step, .step:nth-child(3) { padding: 18px 0; border-left: 0; }
			.step + .step { border-top: 1px solid #d7e3d2; }
		}
	</style>
</head>
<body>
	<header class="topbar">
		<nav class="nav shell" aria-label="Navegacao principal">
			<a class="brand" href="#inicio" aria-label="Reflora, inicio"><span class="brand-mark" aria-hidden="true">✿</span> reflora<span style="color:var(--rose)">.</span></a>
			<div class="nav-links">
				<a href="#impacto">O impacto</a>
				<a href="#descarte">Como descartar</a>
				<a href="#reuso">Reuso</a>
				<a class="nav-cta" href="#coleta">Encontrar coleta ↗</a>
			</div>
		</nav>
	</header>

	<main>
		<section class="hero" id="inicio">
			<div class="shell hero-inner reveal">
				<span class="eyebrow">Cuidado que conecta</span>
				<h1>Tecnologia que <em>floresce</em> de novo.</h1>
				<p class="hero-copy">O ciclo de um aparelho não precisa terminar na gaveta ou no lixo. Descubra como fazer a tecnologia voltar a fazer parte de um futuro mais leve.</p>
				<div class="button-row">
					<a class="button" href="#descarte">Aprender a descartar <span aria-hidden="true">↓</span></a>
					<a class="button secondary" href="#impacto">Entender o impacto</a>
				</div>
				<div class="hero-note"><span aria-hidden="true">✳</span> Pequenos gestos, novos ciclos</div>
			</div>
		</section>

		<div class="ticker" aria-label="Resumo">
			<div class="ticker-inner shell">
				<span><strong>Reparar</strong><span class="dot">✿</span> <strong>Reutilizar</strong><span class="dot">✿</span> <strong>Reciclar</strong></span>
				<span>Seu próximo passo faz diferença ↘</span>
			</div>
		</div>

		<section class="content-section" id="impacto">
			<div class="shell">
				<div class="section-head">
					<div><span class="eyebrow">O lado que não vemos</span><h2>Um aparelho pequeno pode deixar uma marca enorme.</h2></div>
					<p class="section-intro">Quando o lixo eletrônico vai para o lugar errado, materiais perigosos e recursos valiosos se perdem no caminho.</p>
				</div>
				<div class="impact-grid">
					<?php foreach ($impactos as $impacto): ?>
						<article class="impact-card">
							<div class="impact-top"><span><?= e($impacto['numero']) ?> / ALERTA</span><span class="impact-icon" aria-hidden="true"><?= e($impacto['icone']) ?></span></div>
							<h3><?= e($impacto['titulo']) ?></h3>
							<p><?= e($impacto['texto']) ?></p>
						</article>
					<?php endforeach; ?>
				</div>
				<aside class="callout"><p><strong>Importante:</strong> nem todo aparelho contém os mesmos materiais, e o risco depende da composição e de como o resíduo é tratado. Por isso, o descarte deve ser feito por canais apropriados, nunca junto ao lixo doméstico.</p><span class="callout-mark" aria-hidden="true">✳</span></aside>
			</div>
		</section>

		<section class="content-section how-section" id="descarte">
			<div class="shell">
				<div class="section-head">
					<div><span class="eyebrow">Um caminho mais seguro</span><h2>Antes de entregar, prepare. Depois, deixe com quem sabe.</h2></div>
					<p class="section-intro">A coleta seletiva de eletrônicos encaminha cada material para triagem, reaproveitamento ou tratamento adequado.</p>
				</div>
				<div class="steps">
					<?php foreach ($destinos as $destino): ?>
						<article class="step">
							<span class="step-number">PASSO <?= e($destino['passo']) ?></span>
							<h3><?= e($destino['titulo']) ?></h3>
							<p><?= e($destino['texto']) ?></p>
						</article>
					<?php endforeach; ?>
				</div>
				<div class="safety"><span class="safety-mark" aria-hidden="true">!</span><span><strong>Bateria estufada, quente ou danificada?</strong> Não carregue, não pressione e não tente remover. Afaste materiais inflamáveis e contate o fabricante ou um ponto de coleta para receber orientação segura.</span></div>
			</div>
		</section>

		<section class="content-section" id="coleta">
			<div class="shell finder">
				<div>
					<span class="eyebrow">Próximo destino</span>
					<h2>Encontre um ponto de coleta perto de você.</h2>
					<p class="finder-copy">Consulte os localizadores oficiais para verificar endereços, horários e quais tipos de eletrônicos cada ponto recebe. As regras podem variar por localidade.</p>
				</div>
				<div class="finder-actions">
					<a class="finder-link" href="https://greeneletron.org.br/localizador/" target="_blank" rel="noopener noreferrer">Green Eletron <span aria-hidden="true">↗</span></a>
					<a class="finder-link" href="https://abree.org.br/" target="_blank" rel="noopener noreferrer">ABREE <span aria-hidden="true">↗</span></a>
				</div>
			</div>
		</section>

		<section class="content-section" id="reuso" style="padding-top:0">
			<div class="shell">
				<div class="section-head">
					<div><span class="eyebrow">Antes de reciclar</span><h2>Um aparelho usado ainda pode ter muita vida.</h2></div>
					<p class="section-intro">Prolongar a vida útil reduz a necessidade de fabricar novos produtos e evita que equipamentos funcionais virem resíduos cedo demais.</p>
				</div>
				<div class="reuse-grid">
					<div class="reuse-panel"><p>O melhor resíduo é aquele que a gente consegue evitar.</p></div>
					<div>
						<ul class="reuse-list">
							<li><span>01</span><span><strong>Conserte:</strong> troque uma peça ou procure uma assistência técnica antes de substituir o aparelho todo.</span></li>
							<li><span>02</span><span><strong>Doe ou venda:</strong> apague seus dados e encaminhe equipamentos em bom estado para outra pessoa.</span></li>
							<li><span>03</span><span><strong>Reaproveite:</strong> use um celular antigo como câmera, controle de música ou aparelho de testes, se estiver seguro e funcionando.</span></li>
							<li><span>04</span><span><strong>Recicle o que não tem conserto:</strong> componentes eletrônicos exigem triagem especializada; não tente extrair metais em casa.</span></li>
						</ul>
					</div>
				</div>
			</div>
		</section>

		<section class="closing">
			<div class="shell closing-inner">
				<div><span class="eyebrow">Um gesto de cada vez</span><h2>Seu eletrônico antigo pode ser o começo de um novo ciclo.</h2></div>
				<a class="button" href="#coleta">Achar um ponto de coleta <span aria-hidden="true">↗</span></a>
			</div>
		</section>
	</main>

	<footer>
		<div class="shell footer-inner">
			<a class="brand" href="#inicio"><span class="brand-mark" aria-hidden="true">✿</span> reflora.</a>
			<span class="footer-note">Informação para escolhas mais conscientes. Confirme sempre as orientações do ponto de coleta.</span>
			<a href="#inicio">Voltar ao topo ↑</a>
		</div>
	</footer>
</body>
</html>
